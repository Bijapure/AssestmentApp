import java.util.Scanner;

public class AssestTrackApp {

	static Scanner s = new Scanner(System.in);
	static int count = 0;
	static int SerialID = 99;// auto increment to add system from 100, 101 .......
	static AssestDetail assestDetail[];

	public static void main(String[] args) {
		assestDetail = new AssestDetail[1];
		int choice = 0;
		do {
			displayMenu();
			choice = s.nextInt();
			switch (choice) {
			case 1:
				AssestDetail assest = addAssestDetail();
				assestDetail[count++] = assest;
				displayAllAssestTracks(assestDetail);
				break;
			case 2:
				System.out.println("Please Enter the Month name for search : ");
				String month = s.next();
				AssestDetail assestSortedbyModelName[] = searchforAssestbyModelName(assestDetail, month);
				displayAllAssestTracksForPerticularMonth(assestSortedbyModelName, month);
				break;
			case 3:
				DisplaybyQuantityAllocated(assestDetail);
				break;
			case 4:
				AssestDetail updatedAssestDetail = updateAQuantityByModelName(assestDetail);
				displayUpdatedAssestDetail(updatedAssestDetail);
				break;

			case 5:
				deleteById();
				break;
			case 6:
				System.out.println("Thanks For Visiting Assest Track App");
				break;
			default:
				System.out.println("Wrong Choice !!!!!!!!!!");

			}

		} while (choice != 6);
	}

	//delete method to delete a record 
	private static void deleteById() {
		int flag=0;
		System.out.println("Enter serial Number to delete");
		int id = s.nextInt();
		for (int i = 0; i < assestDetail.length; i++) {
			if (id == assestDetail[i].getSerialNumber()) {
				assestDetail[i] = null;
				flag=1;
				System.out.println("Record has been Deleted");
				break;
			}
		}
		if(flag==0)
			System.out.println("No Record Found For this ID : "+id);
	}

	//update a detail 
	private static AssestDetail updateAQuantityByModelName(AssestDetail[] assestDetail2) {
		AssestDetail assestupdated = new AssestDetail();
		System.out.println("Enter Model Name to update : ");
		String modelname = s.next();

		System.out.println("Please Enter for which Month want to update quantity : ");
		String month = s.next();

		System.out.println("Enter Quantity : ");
		int quantity = s.nextInt();
		for (int i = 0; i < assestDetail2.length; i++) {
			if (assestDetail2[i].getModelName().equalsIgnoreCase(modelname)
					&& assestDetail2[i].getAllocatedMonth().equalsIgnoreCase(month)) {
				assestDetail2[i].setQuantity(quantity);
				assestupdated = assestDetail2[i];
			}
		}
		return assestupdated;
	}

	//display method to display updated Record Detail
	private static void displayUpdatedAssestDetail(AssestDetail assestDetail) {
		System.out.println("Updated Details Are as below :");
		System.out.println("Serail Number: " + assestDetail.getSerialNumber());
		System.out.println("Model Name: " + assestDetail.getModelName());
		System.out.println("Allocated Month: " + assestDetail.getAllocatedMonth());
		System.out.println("Quantity: " + assestDetail.getQuantity());
		System.out.println("========================================\n\n");

	}

	//method to sum all quantity depending upon model name
	private static void DisplaybyQuantityAllocated(AssestDetail[] assestDetail2) {
		int countOfQuantity = 0;
		System.out.println("Enter Model Name : ");
		String modelName = s.next();
		for (int i = 0; i < assestDetail2.length; i++) {
			if (assestDetail2[i].getModelName().equals(modelName)) {
				countOfQuantity += assestDetail2[i].getQuantity();
			}
		}

		System.out.println("\nTotal quantity Allocated for " + modelName + " Model : " + countOfQuantity + "\n\n");
	}

	//search a record by model name
	private static AssestDetail[] searchforAssestbyModelName(AssestDetail[] assestDetail, String month) {
		int flag=0;
		for (int i = 0; i < assestDetail.length; i++) {
			if (assestDetail[i] != null) {
				if (assestDetail[i].getAllocatedMonth().equalsIgnoreCase(month)) {
					for (int j = i + 1; j < assestDetail.length; j++) {
						AssestDetail temp = assestDetail[i];
						assestDetail[i] = assestDetail[j];
						assestDetail[j] = temp;
						flag=1;
					}
				}
			}
		}
		if(flag==0)
			System.out.println("No Record Found For this Month");
		
		return assestDetail;
	}

	//display the record by entering month.
	private static void displayAllAssestTracksForPerticularMonth(AssestDetail[] assestDetail2, String month) {
		for (int i = 0; i < assestDetail2.length; i++) {
			if (month.equals(assestDetail[i].getAllocatedMonth())) {
				System.out.println("========================================");
				System.out.println("Serail Number: " + assestDetail[i].getSerialNumber());
				System.out.println("Model Name: " + assestDetail[i].getModelName());
				System.out.println("Allocated Month: " + assestDetail[i].getAllocatedMonth());
				System.out.println("Quantity: " + assestDetail[i].getQuantity());
				System.out.println("========================================");
			}
		}
	}

	private static void displayAllAssestTracks(AssestDetail[] assestDetail2) {
		for (int i = 0; i < assestDetail2.length; i++) {
			System.out.println("========================================");
			System.out.println("Serail Number: " + assestDetail[i].getSerialNumber());
			System.out.println("Model Name: " + assestDetail[i].getModelName());
			System.out.println("Allocated Month: " + assestDetail[i].getAllocatedMonth());
			System.out.println("Quantity: " + assestDetail[i].getQuantity());
			System.out.println("========================================");
		}
	}

	private static AssestDetail addAssestDetail() {
		if (assestDetail.length == count)
			assestDetail = ResizeArray();

		SerialID++;
		AssestDetail assest = new AssestDetail();
		System.out.println("Serail Number [Auto Generated]: " + SerialID);
		assest.setSerialNumber(SerialID);
		System.out.println("Enter Model Name :");
		String modelName = s.next();
		assest.setModelName(modelName);
		System.out.println("Enter Allocated Month Name: ");
		String month = s.next();
		assest.setAllocatedMonth(month);
		System.out.println("Enter Qauntity ");
		int quantity = s.nextInt();
		assest.setQuantity(quantity);

		return assest;
	}

	//resize array (dynamic Array size increment logic)
	private static AssestDetail[] ResizeArray() {
		AssestDetail NewAssestDetail[] = new AssestDetail[count + 1];
		for (int i = 0; i < count; i++) {
			NewAssestDetail[i] = assestDetail[i];
		}
		return NewAssestDetail;
	}

	
	private static void displayMenu() {
		System.out.println("1.Add asset details and display all");
		System.out.println("2.Search assets for given Month and sort the data by Model");
		System.out.println("3.Display total quantity allotted for given Model");
		System.out.println("4.Update Quantity for given Model and display");
		System.out.println("5.Delete A Record by Serial Number\n6.Exit\n\nEnter your Choice");
	}
}
