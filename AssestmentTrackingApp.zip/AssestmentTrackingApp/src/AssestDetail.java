import java.util.Scanner;

public class AssestDetail {
	private int SerialNumber;
	private String ModelName;
	private String AllocatedMonth;
	private int quantity;
	private String[] months = { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };

	Scanner s = new Scanner(System.in);

	public AssestDetail() {
		super();
	}

	public AssestDetail(int serialNumber, String modelName, String allocatedMonth, int quantity) {
		super();
		SerialNumber = serialNumber;
		ModelName = modelName;
		AllocatedMonth = allocatedMonth;
		this.quantity = quantity;
	}

	public int getSerialNumber() {
		return SerialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		SerialNumber = serialNumber;
	}

	public String getModelName() {
		return ModelName;
	}

	public void setModelName(String modelName) {
		int flag = 0;
		if (modelName.equals("HP") || modelName.equals("Lenovo") || modelName.equals("Dell"))
			ModelName = modelName;
		else {
			do {
				System.out.println("Enter Model Name [HP,Lenovo,Dell] only :");
				modelName = s.next();
				if (modelName.equals("HP") || modelName.equals("Lenovo") || modelName.equals("Dell")) {
					flag = 1;
				}

			} while (flag != 1);
			this.ModelName = modelName;
		}
	}

	public String getAllocatedMonth() {
		return AllocatedMonth;
	}

	public void setAllocatedMonth(String allocatedMonth) {
		int flag = 0;
		boolean status = false;
		for (int i = 0; i < months.length; i++) {
			if (months[i].equals(allocatedMonth)) {
				AllocatedMonth = allocatedMonth;
				flag = 1;
			}
		}
		if (flag == 0) {
			do {
				System.out.println("Enter Allocated Month [3-Letter of Any Month]: ");
				allocatedMonth = s.next();
				for (int i = 0; i < months.length; i++) {
					if (months[i].equals(allocatedMonth)) {
						AllocatedMonth = allocatedMonth;
						status = true;
					}
				}

			} while (status != true);

			this.AllocatedMonth = allocatedMonth;
		}
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
